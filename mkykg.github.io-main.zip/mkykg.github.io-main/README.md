# **Welcome to 𝓜𝓚!**

An Amazing browser


> [!IMPORTANT]
> If you fork this repo please consider giving us a star. Thank you!
> 
> Make sure to join our server if you haven't already. Thank you!

[![Join our Discord](https://invidget.switchblade.xyz/TQRThrCjRr)](https://discord.gg/TQRThrCjRr)


## Contributors

[![Contributors](https://contrib.rocks/image?repo=mkykg/mkykg.github.io)](https://github.com/mkykg/mkykg.github.io/graphs/contributors)
