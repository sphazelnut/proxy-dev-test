// search functionality will come here very soon
// yall chose duckduckgo ill add it here
//ill use UV first then ill do scram/settings soon